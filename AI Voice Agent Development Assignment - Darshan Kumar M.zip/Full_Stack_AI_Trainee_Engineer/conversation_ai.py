import requests
import json

# Replace with actual API keys
COHERE_API_KEY = "lllXIwz9GdqGCpRjOJR37823xf9v9dh28WOeVQz8"
ELEVENLABS_API_KEY = "sk_b120fd77088e9f37b6384b0928ac5fd4c7f4d272d83eb1fd"
VOICE_ID = "21m00Tcm4TlvDq8ikWAM"

# Sales conversation flow
def get_sales_response(user_input):
    if "hello" in user_input.lower() or "hi" in user_input.lower():
        return "Hello! This is your AI assistant. How can I assist you today?"
    elif "price" in user_input.lower():
        return "Our service is competitively priced with flexible plans. Would you like a detailed breakdown?"
    elif "features" in user_input.lower():
        return "We offer advanced AI-driven solutions with 24/7 support. What specific features are you looking for?"
    elif "not interested" in user_input.lower():
        return "I understand. Many customers felt the same, but they found great value in our solution. Can I answer any concerns?"
    else:
        return "That's interesting! Can you share more details so I can assist better?"

# Generate AI response using Cohere API
def get_ai_response(user_input):
    url = "https://api.cohere.ai/v1/generate"
    headers = {"Authorization": f"Bearer {COHERE_API_KEY}", "Content-Type": "application/json"}
    data = {"prompt": user_input, "max_tokens": 50}
    response = requests.post(url, json=data, headers=headers)
    return response.json().get("text", "I'm not sure how to respond to that.")

# Convert AI response to speech using ElevenLabs
def text_to_speech(text):
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}"
    headers = {"Accept": "audio/mpeg", "xi-api-key": ELEVENLABS_API_KEY, "Content-Type": "application/json"}
    data = {"text": text, "voice_settings": {"stability": 0.5, "similarity_boost": 0.8}}
    response = requests.post(url, json=data, headers=headers)
    if response.status_code == 200:
        with open("output_audio/output_1.mp3", "wb") as file:
            file.write(response.content)
        print("✅ Audio saved as output.mp3")
    else:
        print(f"❌ Error: {response.text}")

if __name__ == "__main__":
    user_input = input("You: ")
    ai_response = get_sales_response(user_input)
    print(f"AI: {ai_response}")
    text_to_speech(ai_response)
