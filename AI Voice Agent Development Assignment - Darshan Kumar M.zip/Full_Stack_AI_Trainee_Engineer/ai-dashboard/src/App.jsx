// src/App.jsx
import React from "react";

function App() {
  return <h1>AI Dashboard</h1>;
}

export default App;