from twilio.rest import Client

# Twilio credentials (get from Twilio Console)
ACCOUNT_SID = "AC30dc9a90cbaa1160748cd392a62b1d8c"
AUTH_TOKEN = "4e1ccc197ac6333e1fcf9d55c71cbf15"
TWILIO_PHONE_NUMBER = "+17754179392"
RECIPIENT_PHONE_NUMBER = "+919141054527"

client = Client(ACCOUNT_SID, AUTH_TOKEN)

call = client.calls.create(
    to=RECIPIENT_PHONE_NUMBER,
    from_=TWILIO_PHONE_NUMBER,
    twiml="<Response><Say>Hello! This is a test call from your AI agent.</Say></Response>"
)

print(f"Call initiated: {call.sid}")