import pyttsx3

engine = pyttsx3.init(driverName='sapi5')  # For Windows
engine.save_to_file("Hello, this is a test audio for transcription.", "sample.wav")
engine.runAndWait()