import asyncio
import websockets
import json

DEEPGRAM_API_KEY = "7095b621f72e14c4a165b5960c91e0c5caa94fe9"
AUDIO_FILE_PATH = "audio/trimmed_audio.wav"  # Replace with your actual audio file

async def transcribe_audio():
    uri = "wss://api.deepgram.com/v1/listen"

    try:
        async with websockets.connect(uri, extra_headers={"Authorization": f"Token {DEEPGRAM_API_KEY}"}) as ws:
            print("Connected to Deepgram WebSocket!")

            # Open the audio file and stream it
            with open(AUDIO_FILE_PATH, "rb") as audio:
                while True:
                    chunk = audio.read(512)  # Reduce chunk size
                    if not chunk:
                        break
                    try:
                        await ws.send(chunk)  # Send small chunks of audio
                        await asyncio.sleep(0.1)  # Prevent flooding the server
                    except Exception as e:
                        print(f"Error sending chunk: {e}")
                        break  # Exit the loop if sending fails

            print("Audio Sent. Listening for Transcription...")

            while True:
                try:
                    response = await ws.recv()
                    data = json.loads(response)
                    if "channel" in data and "alternatives" in data["channel"]:
                        text = data["channel"]["alternatives"][0]["transcript"]
                        if text:
                            print("User  said:", text)
                except websockets.ConnectionClosed:
                    print("WebSocket connection closed.")
                    break
                except Exception as e:
                    print(f"Error receiving data: {e}")
                    break

    except Exception as e:
        print(f"An error occurred: {e}")

asyncio.run(transcribe_audio())

async with websockets.connect(uri) as ws:
    print("Connected to Deepgram WebSocket!")
    
    try:
        async for message in ws:
            print("Received:", message)  # Debugging
    except Exception as e:
        print(f"WebSocket error: {e}")
