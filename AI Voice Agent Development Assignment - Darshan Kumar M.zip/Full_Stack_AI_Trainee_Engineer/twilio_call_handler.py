from flask import Flask, request, Response
from twilio.twiml.voice_response import VoiceResponse
import requests
import os
import time  # Import time for unique filename generation

# Load environment variables
TWILIO_NUMBER = os.getenv("+17754179392")
DEEPGRAM_API_KEY = os.getenv("7095b621f72e14c4a165b5960c91e0c5caa94fe9")
COHERE_API_KEY = os.getenv("lllXIwz9GdqGCpRjOJR37823xf9v9dh28WOeVQz8")
ELEVENLABS_API_KEY = os.getenv("sk_b120fd77088e9f37b6384b0928ac5fd4c7f4d272d83eb1fd")

app = Flask(__name__)

@app.route("/incoming_call", methods=["POST"])
def incoming_call():
    response = VoiceResponse()
    response.say("Hello! Please speak after the beep. Press any key when done.")
    response.record(timeout=10, transcribe=False, play_beep=True)
    return str(response)

@app.route("/incoming", methods=["POST"])
def handle_incoming_call():
    response = """<?xml version="1.0" encoding="UTF-8"?>
    <Response>
        <Say>Hello! This is your AI voice assistant.</Say>
    </Response>"""
    return Response(response, mimetype="text/xml")

@app.route("/process_audio", methods=["POST"])
def process_audio():
    audio_url = request.form["RecordingUrl"]
    transcript = transcribe_audio(audio_url)
    if not transcript:
        return Response("Transcription failed.", status=500)
    
    ai_response = get_ai_response(transcript)
    audio_file = text_to_speech(ai_response)
    return play_audio_response(audio_file)

def transcribe_audio(audio_url):
    headers = {"Authorization": f"Token {DEEPGRAM_API_KEY}"}
    response = requests.post("https://api.deepgram.com/v1/listen", headers=headers, json={"url": audio_url})
    if response.status_code != 200:
        return ""
    return response.json().get("results", {}).get("channels", [{}])[0].get("alternatives", [{}])[0].get("transcript", "")

def get_ai_response(text):
    headers = {"Authorization": f"Bearer {COHERE_API_KEY}", "Content-Type": "application/json"}
    data = {"prompt": text, "max_tokens": 50}
    response = requests.post("https://api.cohere.ai/generate", json=data, headers=headers)
    if response.status_code != 200:
        return "I'm sorry, I didn't understand that."
    return response.json().get("generations", [{}])[0].get("text", "I'm sorry, I didn't understand that.")

def text_to_speech(text):
    url = f"https://api.elevenlabs.io/v1/text-to-speech"
    headers = {"Accept": "audio/mpeg", "xi-api-key": ELEVENLABS_API_KEY, "Content-Type": "application/json"}
    data = {"text": text, "voice_settings": {"stability": 0.5, "similarity_boost": 0.8}}
    response = requests.post(url, json=data, headers=headers)
    if response.status_code != 200:
        return None
    filename = f"response_{int(time.time())}.mp3"  # Unique filename
    with open(filename, "wb") as file:
        file.write(response.content)
    return filename

def play_audio_response(filename):
    if not os.path.exists(filename):
        return Response("Audio file not found.", status=404)
    with open(filename, "rb") as file:
        return Response(file.read(), mimetype="audio/mpeg")

if __name__ == "__main__":
    app.run(port=5001, debug=True)