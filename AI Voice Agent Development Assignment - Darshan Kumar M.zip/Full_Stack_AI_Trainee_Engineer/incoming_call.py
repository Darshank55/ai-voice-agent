import os
from flask import Flask, request
from twilio.twiml.voice_response import VoiceResponse
from deepgram import Deepgram
import requests
import json

app = Flask(__name__)

# Load API Keys
DEEPGRAM_API_KEY = "7095b621f72e14c4a165b5960c91e0c5caa94fe9"

@app.route("/incoming", methods=["POST"])
def incoming_call():
    """Handles incoming calls and records audio for transcription."""
    response = VoiceResponse()
    response.say("Hello! This is your AI voice assistant. Please speak after the beep.")
    response.record(max_length=10, action="/transcribe")
    return str(response)

@app.route("/transcribe", methods=["POST"])
def transcribe_audio():
    """Sends recorded audio to Deepgram for transcription."""
    recording_url = request.form.get("RecordingUrl")

    if not recording_url:
        return "No recording found", 400

    deepgram_url = "https://api.deepgram.com/v1/listen"
    headers = {
        "Authorization": f"Token {DEEPGRAM_API_KEY}",
        "Content-Type": "application/json"
    }

    # Send audio to Deepgram
    response = requests.post(deepgram_url, headers=headers, json={"url": recording_url})
    
    if response.status_code == 200:
        transcript = response.json()["results"]["channels"][0]["alternatives"][0]["transcript"]
        return f"User said: {transcript}"
    else:
        return f"Deepgram Error: {response.text}", 500

if __name__ == "__main__":
    app.run(port=5000)
