import requests

DEEPGRAM_API_KEY = "7095b621f72e14c4a165b5960c91e0c5caa94fe9"
AUDIO_FILE_PATH = "audio/sample.wav"

with open(AUDIO_FILE_PATH, "rb") as audio_file:
    response = requests.post(
        "https://api.deepgram.com/v1/listen",
        headers={"Authorization": f"Token {DEEPGRAM_API_KEY}"},
        files={"audio": audio_file}
    )

if response.status_code == 200:
    print("Transcription:", response.json()["results"]["channels"][0]["alternatives"][0]["transcript"])
else:
    print("Error:", response.text)