from twilio.rest import Client

# Twilio credentials
account_sid = "AC30dc9a90cbaa1160748cd392a62b1d8c"  # Replace with your Twilio Account SID
auth_token = "4e1ccc197ac6333e1fcf9d55c71cbf15"  # Replace with your Twilio Auth Token
twilio_phone_number = "+17754179392"  # Replace with your Twilio number
recipient_phone_number = "+919141054527"  # Replace with the recipient's phone number

# Initialize Twilio client
client = Client(account_sid, auth_token)

# Make an outgoing call
call = client.calls.create(
    to=recipient_phone_number,
    from_=twilio_phone_number,
    twiml='<Response><Say>Hello! This is an AI voice agent. How can I assist you today?</Say></Response>'
)

print(f"Call initiated with SID: {call.sid}")