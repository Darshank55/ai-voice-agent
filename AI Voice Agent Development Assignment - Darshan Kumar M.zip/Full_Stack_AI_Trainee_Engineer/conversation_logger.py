import requests
import csv
import datetime

# Replace this with your actual ElevenLabs API Key
ELEVENLABS_API_KEY = "sk_b120fd77088e9f37b6384b0928ac5fd4c7f4d272d83eb1fd"
VOICE_ID = "21m00Tcm4TlvDq8ikWAM"  # Change to other ElevenLabs voices if needed
LOG_FILE = "conversation_logs.csv"

def log_conversation(user_input, ai_response):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, user_input, ai_response])
    print("✅ Conversation logged.")

def text_to_speech(text):
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}"
    
    headers = {
        "Accept": "audio/mpeg",
        "xi-api-key": ELEVENLABS_API_KEY,
        "Content-Type": "application/json"
    }
    
    data = {
        "text": text,
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.8
        }
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 200:
        with open("output_audio/output.mp3", "wb") as file:
            file.write(response.content)
        print("✅ Audio saved as output.mp3")
    else:
        print(f"❌ Error: {response.text}")

if __name__ == "__main__":
    text = input("Enter text for speech synthesis: ")
    ai_response = "This is a sample AI response."  # Placeholder for AI-generated response
    log_conversation(text, ai_response)
    text_to_speech(ai_response)