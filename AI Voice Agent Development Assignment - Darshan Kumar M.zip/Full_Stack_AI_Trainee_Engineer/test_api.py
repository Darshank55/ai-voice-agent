import cohere

# Initialize Cohere API with your key
co = cohere.Client("lllXIwz9GdqGCpRjOJR37823xf9v9dh28WOeVQz8")  # Replace with your API key

# Generate a response
response = co.generate(
    model="command", 
    prompt="Tell me about AI voice agents.",
    max_tokens=100
)

# Print the response
print(response.generations[0].text)