import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableRow, TableCell } from "@/components/ui/table";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const Dashboard = () => {
  const [calls, setCalls] = useState([]);

  useEffect(() => {
    fetch("/api/call-logs")
      .then((res) => res.json())
      .then((data) => setCalls(data));
  }, []);

  return (
    <div className="p-6 grid gap-6 grid-cols-1 md:grid-cols-2">
      {/* Recent Calls Table */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Recent Calls</h2>
          <Table>
            <TableHeader>
              <TableRow>
                <TableCell>From</TableCell>
                <TableCell>To</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Duration</TableCell>
              </TableRow>
            </TableHeader>
            {calls.map((call, index) => (
              <TableRow key={index}>
                <TableCell>{call.from}</TableCell>
                <TableCell>{call.to}</TableCell>
                <TableCell>{call.status}</TableCell>
                <TableCell>{call.duration}s</TableCell>
              </TableRow>
            ))}
          </Table>
        </CardContent>
      </Card>

      {/* Call Analytics Chart */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Call Analytics</h2>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={calls}>
              <XAxis dataKey="timestamp" hide />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="duration" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;