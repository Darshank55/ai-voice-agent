from pydub.utils import mediainfo

audio_file_path = "audio/sample.wav"
info = mediainfo(audio_file_path)

print("Audio File Information:")
print(f"Duration: {info['duration']} seconds")
print(f"Channels: {info['channels']}")
print(f"Sample Rate: {info['sample_rate']} Hz")
print(f"Bit Rate: {info['bit_rate']} bps")